package com.gl.springdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.springdemo.dao.StudentDAO;
import com.gl.springdemo.entity.Student;




@Service
public class StudentServiceImp implements StudentService {

	@Autowired
	StudentDAO studentDAOImp;
	@Override
	public List<Student> findAll() {
		// TODO Auto-generated method stub
		return studentDAOImp.findAll();
	}



	

	@Override
	public void deleteById(int id) {
		studentDAOImp.deleteById(id);
		
	}

	



	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		return studentDAOImp.findById(id);
	}



	@Override
	public void save(Student student) {
		// TODO Auto-generated method stub
		studentDAOImp.save(student);
	}

	
}
